              </button>
              <button onClick={() => openGoogleMaps()}
                className="flex-1 py-3 rounded-xl border border-primary text-primary font-semibold text-sm flex items-center justify-center gap-2">
                <Navigation className="w-4 h-4" /> View Directions
              </button>
            </div>
            <button onClick={() => navigate("/my-listings")} className="w-full py-3 rounded-xl border border-border text-foreground font-medium text-sm">
              Back to My Listings
            </button>
          </div>
        )}

        {/* Delivery Pick Up */}
        {step === "pickup" && (
          <div className="space-y-4">
            <div className="bg-card rounded-xl p-4 border border-border">
              <p className="text-xs font-semibold text-foreground mb-2">Tracking Number</p>
              <p className="text-lg font-bold text-primary mb-3">{trackingNumber}</p>
              <div className="flex gap-2">
                <button onClick={() => { navigator.clipboard.writeText(trackingNumber); toast.success("Copied!"); }}
                  className="flex-1 py-2 rounded-lg border border-border text-foreground text-xs font-medium flex items-center justify-center gap-1.5">
                  <Copy className="w-3.5 h-3.5" /> Copy
                </button>
                <button onClick={() => navigate(`/print-label/${trackingNumber}`)}
                  className="flex-1 py-2 rounded-lg border border-border text-foreground text-xs font-medium flex items-center justify-center gap-1.5">
                  <Printer className="w-3.5 h-3.5" /> Print Label
                </button>
              </div>
            </div>

            <div className="bg-accent/30 rounded-xl p-5 text-center">
              <p className="text-2xl mb-2">📦</p>
              <p className="text-sm font-semibold text-foreground">Courier will pick up within 2 days</p>
            </div>

            <button onClick={() => navigate("/my-listings")} className="w-full py-3 rounded-xl border border-border text-foreground font-medium text-sm">
              Back to My Listings
            </button>
          </div>
        )}
      </div>

      {/* Confirmation Modal - now proceeds to KG step */}
      {selectedOrg && step === "select" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-6">
          <div className="bg-card rounded-2xl p-6 w-full max-w-sm border border-border">
            <h3 className="font-semibold text-foreground text-center mb-2">Confirm Surplus Donation</h3>
            <p className="text-sm text-muted-foreground text-center mb-5">
              Are you sure you want to donate your surplus <span className="font-medium text-foreground">{listing.name}</span> to <span className="font-medium text-foreground">{selectedOrg.name}</span>?
            </p>
            <div className="flex gap-3">
              <button onClick={() => setSelectedOrg(null)}
                className="flex-1 py-2.5 rounded-xl border border-border text-foreground font-medium text-sm">Cancel</button>
              <button onClick={handleProceedToKg}
                className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm">Next</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DonateSurplusPage;
