#!/usr/bin/env python3
"""Push changed files to GitHub via the Contents API."""

import subprocess
import base64
import json
import urllib.request
import urllib.error
import os

REPO = "ern2306/agro-save-connect"
BRANCH = "main"
REPO_DIR = "/home/ubuntu/agro-save-connect"

# Files to push
FILES_TO_PUSH = [
    "src/pages/AddListingPage.tsx",
    "src/pages/OrderDetailsPage.tsx",
    "src/pages/OrderPage.tsx",
    "src/pages/RefundPage.tsx",
]

# Get the token
token = subprocess.check_output(["gh", "auth", "token"], text=True).strip()
headers = {
    "Authorization": f"token {token}",
    "Accept": "application/vnd.github.v3+json",
    "Content-Type": "application/json",
}


def api_request(url, method="GET", data=None):
    req = urllib.request.Request(url, headers=headers, method=method)
    if data:
        req.data = json.dumps(data).encode()
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read()), resp.status
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"  HTTP {e.code}: {body[:200]}")
        return None, e.code


def get_file_sha(path):
    url = f"https://api.github.com/repos/{REPO}/contents/{path}?ref={BRANCH}"
    data, status = api_request(url)
    if data and "sha" in data:
        return data["sha"]
    return None


def push_file(filepath):
    full_path = os.path.join(REPO_DIR, filepath)
    with open(full_path, "r") as f:
        content = f.read()

    encoded = base64.b64encode(content.encode()).decode()
    sha = get_file_sha(filepath)

    url = f"https://api.github.com/repos/{REPO}/contents/{filepath}"
    payload = {
        "message": f"Update {filepath} with feature fixes",
        "content": encoded,
        "branch": BRANCH,
    }
    if sha:
        payload["sha"] = sha

    print(f"Pushing {filepath} (sha: {sha[:8] if sha else 'new'})...")
    result, status = api_request(url, method="PUT", data=payload)
    if result and "content" in result:
        print(f"  ✓ Successfully pushed {filepath}")
        return True
    else:
        print(f"  ✗ Failed to push {filepath} (status: {status})")
        return False


success_count = 0
for f in FILES_TO_PUSH:
    if push_file(f):
        success_count += 1

print(f"\nDone: {success_count}/{len(FILES_TO_PUSH)} files pushed successfully.")
